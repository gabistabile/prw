<?php

        $peso = $_GET["PESO"];
        $altura = $_GET["ALTURA"];
        $imc = $peso / $altura;


        "SEU PESO: ".$_GET['txtPeso'];
        "SUA ALTURA: ".$_GET['txtAltura'];
        "SEU IMC: ".$imc;

?>
<?php

/*Efetue um script PHP que a partir de dois valores quaisquer efetue
sua multiplicação e apresente o resultado utilizando para isso apenas o operador “+”, visto que:
• (3 * 5) = 5 + 5 + 5
• (4 * 12) = 12 + 12 + 12 + 12*/

    $N1 = 100; //VALOR UM
    $N2 = 3;  //VALOR DOIS
    $resultado = 100 + 100 + 100; //RESULTADO DE (3 * 100)

    do{

        echo "O VALOR DO RESULTADO É: ".$resultado;

    }while($resultado == 1);
?>
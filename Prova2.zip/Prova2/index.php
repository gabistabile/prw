<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> MENU PRINCIPAL </title>
    <link rel = "stylesheet" href = "estilo.css">
</head>
<body>
    <h1> MENU PRINCIPAL </h1>
    <hr>
    <div id="menu">
        <ul>
            <li><a href="cadastro_fluxo_caixa.html">CADASTRO FLUXO DE CAIXA</a></li>
            <li><a href="listar_fluxo_caixa.php">LISTAGEM DE FLUXO DE CAIXA</a></li> 
            <li><a href="consulta_fluxo_caixa.php">CONSULTA SALDO DO CAIXA</a></li> 
        </ul>
    </div>
</body>
</html>